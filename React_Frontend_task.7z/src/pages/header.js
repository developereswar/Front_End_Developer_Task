import React, { Component } from "react";
import { Navbar, Nav } from "react-bootstrap";
import { Redirect } from "react-router";
class Header extends Component {
  logout = () => {
    localStorage.clear();
  };

  checkLogout = () => {
    return <Redirect to="/login" />;
  }

  render() {

    return (
      <Navbar bg="light" expand="lg">
        {this.checkLogout()}
        <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse className="justify-content-end">
          <Nav>
            <Nav.Link onClick={this.logout}>Logout</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}

export default Header;
