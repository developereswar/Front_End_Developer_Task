import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { loginauth } from "../actions/actions";
import { Button, Container, Form, Row, Col } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import { async } from "q";
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loginData: {},
      redirect: false,
      token: null
    };
  }
  // static getDerivedStateFromProps(nextProps, prevState) {
  //   if (nextProps.loginAuth !== this.props.loginAuth) {

  //   }
  // }


  renderRedirect = () => {
    let tokeProps = this.props.tokeProps;
    if(tokeProps){
      localStorage.setItem('token', tokeProps.token)
    }
    let storedToken = localStorage.getItem('token');
    console.log(storedToken)
    if (storedToken && storedToken != 'undefined') {
      return <Redirect to="/dashboard" />;
    }else{
      return <Redirect to="/login" />;
    }
  };
  onChangeHandler = event => {
    let value = event.target.value;
    let name = event.target.name;
    const { loginData } = this.state;
    loginData[name] = value;
    this.setState({ loginData });
  };
  login = () => {
    this.props.loginauth(this.state.loginData);
    this.renderRedirect();
  };
  render() {
    const { loginData, redirect } = this.state;

    return (
      <Container>
        {this.renderRedirect()}
        <Row className="justify-content-md-center rows">
          <Col xs="12" md="6" lg="6">
            <Form id="formContent">
              <Form.Group controlId="formBasicEmail">
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="name"
                  name="username"
                  onChange={this.onChangeHandler}
                  value={loginData.username ? loginData.username : ""}
                  placeholder="Enter your username"
                />
              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  name="password"
                  onChange={this.onChangeHandler}
                  value={loginData.password ? loginData.password : ""}
                  placeholder="Password"
                />
              </Form.Group>
              <Button variant="primary" onClick={this.login} type="button">
                Submit
              </Button>
            </Form>
          </Col>
        </Row>
      </Container>
    );
  }
}
const mapStateToProps = state => {
  return {
    tokeProps: state.loginauth
  };
};
const mapDispatchToState = dispacth => {
  return bindActionCreators(
    {
      loginauth: loginauth
    },
    dispacth
  );
};
export default connect(
  mapStateToProps,
  mapDispatchToState
)(Login);
