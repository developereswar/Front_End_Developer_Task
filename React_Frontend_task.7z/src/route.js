import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
// Routing components
import { Login, Dashboard } from "./pages/index";
import Header from "./pages/header";
const route = [
  {
    path: "/login",
    component: Login,
    exact: true
  },
  {
    path: "/dashboard",
    component: Dashboard,
    exact: false
  }
];

const AppRoute = () => {
  return (
    <Router>
      <Header />
      {route.map((e, i) => {
        return (
          <Route
            exact={e.exact}
            path={e.path}
            key={i}
            component={e.component}
          />
        );
      })}
    </Router>
  );
};
export default AppRoute;
