import { LOGINAUTH, DEVICELIST, DEVICEDETAIL } from "./actionType";
import Axios from "axios";

let token = "Bearer " + localStorage.getItem("token");

export const loginauth = userData => {
  const auth_key = "Basic " + btoa(userData.username + ":" + userData.password);
  return dispatch => {
    Axios.post(
      "https://dl5opah3vc.execute-api.ap-south-1.amazonaws.com/latest/login",
      {},
      { headers: { Authorization: auth_key } }
    )
      .then(res => {
        dispatch({
          type: LOGINAUTH,
          payload: res.data
        });
      })
      .catch(err => {
        if (err)
          dispatch({
            type: LOGINAUTH,
            payload: { error: "Username & PassWord MisMatch" }
          });
      });
  };
};

export const deviceList = () => {
console.log("token", token)
  return dispatch => {
    Axios.get(
      "https://dl5opah3vc.execute-api.ap-south-1.amazonaws.com/latest/devices",
      { headers: { Authorization: token } }
    ).then(res => {
      console.log(res);
      dispatch({
        type: DEVICELIST,
        payload: res.data
      });
    });
  };
};

export const deviceDetail = deviceNo => {
  deviceNo = 'C46';
  return dispatch => {
    Axios.get(
      `https://dl5opah3vc.execute-api.ap-south-1.amazonaws.com/latest?device=${deviceNo}&page=2`,
      { headers: { Authorization: token } }
    )
      .then(res => {
        dispatch({
          type: DEVICEDETAIL,
          payload: res.data
        });
      })
      .catch(err => {
        dispatch({
          type: DEVICEDETAIL,
          payload: { error: "Error Connection" }
        });
      });
  };
};
