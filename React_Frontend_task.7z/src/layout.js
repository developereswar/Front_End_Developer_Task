import React from "react";
import Login from "./pages/login";
class Layout extends React.Component {
  getLogin() {
    return <Login />;
  }
  render() {
    return <div>{this.getLogin()}</div>;
  }
}

export default Layout;
